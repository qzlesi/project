<?php
  include("hed.php");
?>
	<?php
	  $name=$_POST["name"];
	  $user1=$_POST["user"];
	  $pass=$_POST["pass"];
	  $email=$_POST["email"];
	  echo("نام :" .$name ."<br><br>");
	  echo("نام کاربری:" .$user1 ."<br><br>");
	  echo("پسوورد:" .$pass ."<br><br>");
	  echo("ایمیل:" .$email ."<br><br>");
      //----------------------
      $link= mysqli_connect("localhost","root","","signin");
      if(mysqli_connect_errno())
		  exit("exit");
      $q="INSERT INTO `info` (ID, USER, NAME, PASSWORD, EMAIL) VALUES (NULL, '$name', '$user1', '$pass', '$email')";

      if(mysqli_query($link,$q)===true)
		  echo("sub");
      else
		  echo("erorr");
      mysqli_close($link);
	?>
<?php
   include("foot.php");	  
?>