<?php
  include("hed.php");
?>
  <form action="s6-1.php" method="post">
	 <table width="50%">
  <tbody>
    <tr>
      <td>نام :</td>
      <td><input name="name" type="text" id="name"></td>
    </tr>
    <tr>
      <td>نام کاربری:</td>
      <td><input name="user" type="text" id="user"></td>
    </tr>
    <tr>
      <td>پسوورد:</td>
      <td><input name="pass" type="password" id="pass"></td>
    </tr>
    <tr>
      <td>ایمیل:</td>
      <td><input name="email" type="text" id="email"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="reset" value="بازنشانی">
		  <input name="run" type="submit" id="run" value="اجرا">
	  </td>
    </tr>
  </tbody>
</table>

	</form>
<?php
   include("foot.php");	  
?>