<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body dir="rtl">
	<table width="100%" border="1">
  <tbody>
    <tr>
      <td style="text-align: center; font-size:60px; background-color: #8A9FE1" >هنرستان تربیت</td>
    </tr>
    <tr>
      <td><table width="100%" height="300px" border="1">
  <tbody>
    <tr>
      <td width="30%" style="font-size:50px; text-align: center; background-color: #69DD97">لینک</td>
		      <td width="69%" style="font-size:50px; text-align: center; background-color: #C8DD66">