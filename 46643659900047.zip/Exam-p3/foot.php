</td>
</tr>
  </tbody>
</table>
</td>
    </tr>
    <tr>
      <td height="100px" style="font-size:50px; text-align: center; background-color: #8A9FE1">آدرس:</td>
    </tr>
  </tbody>
</table>

</body>
</html>