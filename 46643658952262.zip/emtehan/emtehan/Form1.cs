﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace emtehan
{
    public partial class Form1 : Form
    {
        int i = 1;
        int j = 1;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToLongTimeString();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CheckPass_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPass.Checked == true)
                txtPass.PasswordChar = '\0';
            else
                txtPass.PasswordChar = '*';
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboUser.Items.Add(txtPass.Text);
            txtPass.Clear();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                pic.ImageLocation = openFileDialog1.FileName;
        }

        private void OpenFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void TxtPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            if(comboUser.Text=="majid"&&txtPass.Text=="1234")
            {
                MessageBox.Show("welcome majid");
                Form2 f2 = new Form2();
                f2.Show();
                this.Hide();
               
            }
            else
            {
                if (comboUser.Text == "abol" && txtPass.Text == "4321")
                {
                    MessageBox.Show("welcome abol");
                    Form2 f2 = new Form2();
                    f2.Show();
                    this.Hide();
                }
                else
                {
                    if (comboUser.Text == "arman" && txtPass.Text == "0000")
                    {
                        MessageBox.Show("welcome arman");
                        Form2 f2 = new Form2();
                        f2.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Erorr", "erorr", MessageBoxButtons.RetryCancel);
                    }
                }
            }
           
            
        }
        private void Timer2_Tick(object sender, EventArgs e)
        {
           
        }
    }
}
