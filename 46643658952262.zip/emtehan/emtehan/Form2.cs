﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace emtehan
{
    public partial class Form2 : Form
    {
        int n;
        int i;
        int score = 0,  min = 10, sec = 0, sec1 = 10;
        int sum = 0;

        Random rnd = new Random();

        private void Timer1_Tick(object sender, EventArgs e)
        {
            sec += 1;
            lbltt.Text = min.ToString();
            if (sec==60)
            {
                sec = 0;
                min -= 1;
            }
            
            if(min==0)
            {
                btnNew.Enabled = false;
                btnExit.Enabled = false;
                txtJJ.Enabled = false;
                MessageBox.Show("finish!");
            }
        }

        private void BtnNew_Click(object sender, EventArgs e)
        {
            score++;
            n = rnd.Next(1, 9);
            i = rnd.Next(1, 9);
            lbl1.Text = n.ToString();
            lbl2.Text = i.ToString();
            lblqs.Text = score.ToString();
            sum = n + i;
        }

        private void BtnEnd_Click(object sender, EventArgs e)
        {
            score++;
            if(sum.ToString()==txtJJ.Text)
            {
                n = rnd.Next(1, 9);
                i = rnd.Next(1, 9);
                lbl1.Text = n.ToString();
                lbl2.Text = i.ToString();
                score += 1;
                lblss.Text = score.ToString();
            }
            else
            {
                n = rnd.Next(1, 9);
                i = rnd.Next(1, 9);
                lbl1.Text = n.ToString();
                lbl2.Text = i.ToString();
                score -= 1;
                lblss.Text = score.ToString();
            }
            lblqs.Text = score.ToString();
        }

        private void Timer2_Tick(object sender, EventArgs e)
        {
            sec1 -= 1;
            label1.Text = sec1.ToString();
            if(sec1==0)
            {
                sec1 = 10;
                n = rnd.Next(1, 9);
                i = rnd.Next(1, 9);
                lbl1.Text = n.ToString();
                lbl2.Text = i.ToString();
            }
        }

        private void Lbltt_Click(object sender, EventArgs e)
        {

        }

        private void Lblss_Click(object sender, EventArgs e)
        {

        }

        public Form2()
        {
            InitializeComponent();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void Lbl1_Click(object sender, EventArgs e)
        {
           
        }
    }
}
